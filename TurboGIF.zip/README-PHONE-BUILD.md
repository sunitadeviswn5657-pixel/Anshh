# Turbo GIF — phone-only cloud build

## Build without a PC or Termux

This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.
GitHub's cloud runner compiles the debug APK; your phone only needs a browser.

1. Sign in to GitHub in your phone browser and create a **public or private** repository named `TurboGIF`.
2. In the repository, use **Add file → Upload files** and upload the project files and folders from this ZIP. Make sure `.github/workflows/android.yml` is included. If GitHub's mobile upload UI hides dot-folders, create `.github/workflows/android.yml` using **Add file → Create new file** and paste its contents from this project.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build Turbo GIF APK** and, if needed, tap **Run workflow**.
5. Wait for the run to finish with a green check.
6. Open the completed run, scroll to **Artifacts**, and download `TurboGIF-debug-apk`.
7. Extract the downloaded artifact ZIP. Install `app-debug.apk`. Android may ask you to allow your browser or file manager to install unknown apps.

## Enable the keyboard

1. Open Turbo GIF.
2. Tap **Enable Turbo GIF keyboard** and enable it in Android's keyboard settings.
3. Tap **Choose Turbo GIF keyboard** and select Turbo GIF.
4. Import a local GIF, or enter a Tenor API key and search.
5. In a compatible text field, switch to Turbo GIF and tap **My GIF**.

## Notes and limitations

- This is a starter prototype, not a tested production app.
- Tenor online search requires your own Tenor API key.
- YouTube may reject GIF content from third-party keyboards. The keyboard cannot enable YouTube's native GIF-comment feature or bypass YouTube restrictions.
- The keyboard attempts Android rich-content insertion. The target app must support and accept `image/gif`.
- The prototype currently keeps one selected GIF at a time.
- Keep your Tenor API key private. It is stored locally in app preferences, but a production app should use a protected backend rather than embedding a long-lived key in a client.
