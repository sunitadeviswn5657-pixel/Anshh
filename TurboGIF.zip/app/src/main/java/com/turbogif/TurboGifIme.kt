package com.turbogif

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputContentInfo
import android.content.ClipDescription
import android.net.Uri
import android.widget.*
import androidx.core.content.FileProvider
import android.graphics.Color
import android.os.Bundle
import java.net.URL
import java.net.HttpURLConnection
import kotlin.concurrent.thread

class TurboGifIme : InputMethodService() {
    private lateinit var root: LinearLayout
    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(25, 25, 36))
            setPadding(8, 8, 8, 8)
        }
        val header = TextView(this).apply {
            text = "TURBO GIF   •   Tap a GIF to insert"
            setTextColor(Color.WHITE); textSize = 16f; setPadding(8, 12, 8, 12)
        }
        root.addView(header)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val my = Button(this).apply { text = "My GIF" }
        my.setOnClickListener { sendSavedGif() }
        val text = Button(this).apply { text = "ABC" }
        text.setOnClickListener { currentInputConnection?.commitText("", 1); requestHideSelf() }
        row.addView(my, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val note = TextView(this).apply {
            text = "Use the app to import a GIF or select one from Tenor. GIF insertion only works in apps that accept image content."
            setTextColor(Color.LTGRAY); textSize = 12f; setPadding(8, 8, 8, 8)
        }
        root.addView(note)
        return root
    }

    private fun sendSavedGif() {
        val raw = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
            .getString(MainActivity.KEY_GIF, null)
        if (raw.isNullOrBlank()) {
            Toast.makeText(this, "Import or select a GIF in Turbo GIF first.", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = Uri.parse(raw)
        if (raw.startsWith("https://")) {
            thread {
                try {
                    val conn = (URL(raw).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000; readTimeout = 12000; instanceFollowRedirects = true
                    }
                    val bytes = conn.inputStream.use { it.readBytes() }
                    conn.disconnect()
                    val cache = java.io.File(cacheDir, "selected.gif")
                    cache.writeBytes(bytes)
                    runOnUiThread { insertContent(FileProvider.getUriForFile(this, "$packageName.fileprovider", cache), "image/gif") }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Couldn't load GIF: ${e.message}", Toast.LENGTH_LONG).show() }
                }
            }
        } else {
            insertContent(uri, "image/gif")
        }
    }

    private fun insertContent(uri: Uri, mime: String) {
        val ic = currentInputConnection ?: return
        val desc = ClipDescription("Turbo GIF", arrayOf(mime))
        val info = InputContentInfo(uri, desc, null)
        val opts = Bundle()
        val granted = try {
            ic.commitContent(info, InputConnection.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, opts)
        } catch (_: Exception) { false }
        if (!granted) Toast.makeText(this, "This app/text field doesn't accept GIF image insertion. YouTube may not support it here.", Toast.LENGTH_LONG).show()
        else Toast.makeText(this, "GIF sent to the app.", Toast.LENGTH_SHORT).show()
    }
}
