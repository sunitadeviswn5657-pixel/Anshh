package com.turbogif

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.graphics.Color
import android.view.ViewGroup
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    companion object {
        const val PREFS = "turbo_gif"
        const val KEY_TENOR = "tenor_key"
        const val KEY_GIF = "selected_gif"
    }
    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var keyBox: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(18, 18, 26))
        }
        fun label(s: String, size: Float = 16f) = TextView(this).apply {
            text = s; textSize = size; setTextColor(Color.WHITE); setPadding(0, 10, 0, 10)
        }
        page.addView(label("TURBO GIF", 28f))
        page.addView(label("Your GIF keyboard for Android"))
        val enable = Button(this).apply { text = "1. Enable Turbo GIF keyboard" }
        enable.setOnClickListener {
            startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS"))
            status.text = "Enable Turbo GIF Keyboard in the keyboard list."
        }
        page.addView(enable)
        val choose = Button(this).apply { text = "2. Choose Turbo GIF keyboard" }
        choose.setOnClickListener {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        }
        page.addView(choose)
        val import = Button(this).apply { text = "Import a GIF from this phone" }
        import.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "image/gif"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            startActivityForResult(i, 11)
        }
        page.addView(import)
        page.addView(label("Online GIF search (Tenor)"))
        keyBox = EditText(this).apply {
            hint = "Optional Tenor API key"; setSingleLine(true)
            setText(prefs.getString(KEY_TENOR, ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
        }
        page.addView(keyBox)
        val saveKey = Button(this).apply { text = "Save API key" }
        saveKey.setOnClickListener {
            prefs.edit().putString(KEY_TENOR, keyBox.text.toString().trim()).apply()
            status.text = "API key saved on this device."
        }
        page.addView(saveKey)
        val query = EditText(this).apply {
            hint = "Search GIFs (e.g. cat, wow, dance)"; setSingleLine(true)
        }
        page.addView(query)
        val search = Button(this).apply { text = "Search Tenor" }
        search.setOnClickListener { searchTenor(query.text.toString().trim()) }
        page.addView(search)
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(results) }
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        status = label("Tip: In a text field, switch to Turbo GIF and tap a GIF.")
        page.addView(status)
        setContentView(page)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 11 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_GIF, uri.toString()).apply()
            status.text = "GIF imported. Open the Turbo GIF keyboard and tap “My GIF”."
        }
    }

    private fun searchTenor(q: String) {
        val key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_TENOR, "") ?: ""
        if (key.isBlank()) {
            status.text = "Add a Tenor API key first. Tenor requires an API key for search."
            return
        }
        if (q.isBlank()) { status.text = "Type a search term first."; return }
        status.text = "Searching…"
        thread {
            try {
                val url = URL("https://tenor.googleapis.com/v2/search?q=${java.net.URLEncoder.encode(q, "UTF-8")}&key=${java.net.URLEncoder.encode(key, "UTF-8")}&limit=12&media_filter=tinygif,gif")
                val c = (url.openConnection() as HttpURLConnection).apply {
                    connectTimeout = 12000; readTimeout = 12000
                }
                val body = c.inputStream.bufferedReader().use { it.readText() }
                c.disconnect()
                val arr = JSONObject(body).optJSONArray("results")
                val items = mutableListOf<Pair<String, String>>()
                if (arr != null) for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    val formats = obj.optJSONObject("media_formats") ?: continue
                    val media = formats.optJSONObject("gif") ?: formats.optJSONObject("tinygif") ?: continue
                    val gifUrl = media.optString("url")
                    if (gifUrl.startsWith("https://")) items.add(obj.optString("content_description", "GIF") to gifUrl)
                }
                runOnUiThread {
                    results.removeAllViews()
                    items.forEach { (title, link) ->
                        val b = Button(this).apply { text = "Use: $title" }
                        b.setOnClickListener {
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_GIF, link).apply()
                            status.text = "GIF selected. Switch to Turbo GIF keyboard and tap “Selected GIF”."
                        }
                        results.addView(b)
                    }
                    status.text = if (items.isEmpty()) "No GIFs found." else "${items.size} GIFs found. Tap one to select it."
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Search failed: ${e.message ?: "network/API error"}" }
            }
        }
    }
}
