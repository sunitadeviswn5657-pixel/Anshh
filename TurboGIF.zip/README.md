# Turbo GIF (Android)

A starter Android IME keyboard for Android 8+ / Android 16. It supports:
- Importing one local GIF through Android's document picker.
- Searching Tenor using a developer API key.
- Selecting a result and attempting insertion through Android's `InputConnection.commitContent()` API.

## Important YouTube limitation
This app does **not** bypass YouTube's comment UI or enable GIF comments on accounts where YouTube has not enabled them. Android keyboards can send rich image content only when the target app/editor advertises and accepts the relevant MIME type. YouTube may reject `image/gif`; if so, the keyboard reports that insertion was not accepted. Do not expect a GIF to appear in a YouTube comment just because it is selected here.

## Build
Open this folder in Android Studio (or a compatible Android IDE), allow Gradle sync, then Build > Build APK(s). This project uses Android Gradle Plugin 8.9.2, Kotlin 2.1.10, compile SDK 35, min SDK 26.

## Install and enable
1. Install the generated APK.
2. Open Turbo GIF.
3. Tap **Enable Turbo GIF keyboard**, enable it in Android settings.
4. Tap **Choose Turbo GIF keyboard** and select Turbo GIF.
5. Import a local GIF, or add a Tenor API key and search.
6. In a text field, switch keyboards and tap **My GIF**.

## Tenor API key
Tenor API access requires a key. Create/configure a key in Google's Tenor developer portal and paste it into the app. Keep the key private. The key is stored locally in app preferences; this prototype does not have a backend or key-proxy.

## Current prototype limitations
- One selected GIF at a time (not yet a full searchable local gallery).
- Remote GIFs are downloaded into app cache before insertion. The `file://` URI path may not be accepted by all target apps; production implementation should use a `FileProvider` content URI and grant read access.
- Local document-provider URIs are passed through to the editor; target apps must accept them.
- YouTube compatibility is not guaranteed. Native YouTube GIF comments, where available, are controlled by YouTube's rollout and supported GIF catalog.
- No accessibility scraping, root, Shizuku, or overlay permissions are used.
